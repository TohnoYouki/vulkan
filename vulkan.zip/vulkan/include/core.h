#pragma once
#include <memory>
#include <vulkan/vulkan.h>

class Instance;
typedef std::shared_ptr<Instance> PInstance;

class Surface;
typedef std::shared_ptr<Surface> PSurface;
typedef VkResult SurfaceCreateFn(
    VkInstance instance, void * window, VkSurfaceKHR * surface);