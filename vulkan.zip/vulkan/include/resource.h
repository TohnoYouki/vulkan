#pragma once
#include "core.h"

class InstanceResource {
protected:
    PInstance mInstance = nullptr;
    InstanceResource(const PInstance & instance): mInstance(instance) {};
    InstanceResource(const InstanceResource &) = delete;
    InstanceResource & operator=(const InstanceResource &) = delete;
    InstanceResource(InstanceResource &&) = delete;
    InstanceResource & operator=(InstanceResource &&) = delete;
};