#pragma once
#include <set>
#include <vector>
#include <string>
#include <vulkan/vulkan.h>

class PhysicalDevice {
private:
    VkPhysicalDevice mDevice = VK_NULL_HANDLE;
    PhysicalDevice(const PhysicalDevice &) = delete;
    //PhysicalDevice & operator=(const PhysicalDevice &) = delete;
    //PhysicalDevice(PhysicalDevice &&) = delete;
    //PhysicalDevice & operator=(PhysicalDevice &&) = delete;
public:
    PhysicalDevice(const VkPhysicalDevice & device);

    VkPhysicalDeviceProperties mProperties;
    VkPhysicalDeviceFeatures mFeatures;
    std::vector<VkQueueFamilyProperties> mQueues;
    std::vector<VkExtensionProperties> mExtensions;

    operator const VkPhysicalDevice & () const { return mDevice; }
    
    bool CheckExtensionsSupport(
        const std::vector<const char *> names) const;
};