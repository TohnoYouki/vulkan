#pragma once
#include "core.h"
#include "instance.h"
#include "resource.h"

class Surface : InstanceResource {
private:
    VkSurfaceKHR mSurface = VK_NULL_HANDLE;
    Surface(const PInstance & instance, const VkSurfaceKHR & surface);
public:
    inline operator const VkSurfaceKHR & () const { return mSurface; }

    static PSurface CreateSurface(
        const PInstance & instance, void * window, SurfaceCreateFn fn);

    ~Surface();
};