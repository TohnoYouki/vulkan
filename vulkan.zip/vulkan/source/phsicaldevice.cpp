#include "physicaldevice.h"

PhysicalDevice::PhysicalDevice(const VkPhysicalDevice & device) {
    mDevice = device;
    vkGetPhysicalDeviceFeatures(mDevice, &mFeatures);
    vkGetPhysicalDeviceProperties(mDevice, &mProperties);
    uint32_t count;
    vkGetPhysicalDeviceQueueFamilyProperties(mDevice, &count, nullptr);
    mQueues.resize(count);
    vkGetPhysicalDeviceQueueFamilyProperties(mDevice, &count, mQueues.data());
    vkEnumerateDeviceExtensionProperties(mDevice, nullptr, &count, nullptr);
    mExtensions.resize(count);
    vkEnumerateDeviceExtensionProperties(
        mDevice, nullptr, &count, mExtensions.data());
}

bool PhysicalDevice::CheckExtensionsSupport(
    const std::vector<const char *> names) const {
    std::set<std::string> required(names.begin(), names.end());
    for (const auto & extension : mExtensions) {
        required.erase(extension.extensionName);
    }
    return required.empty();
}