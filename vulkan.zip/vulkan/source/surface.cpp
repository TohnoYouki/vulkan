#include "surface.h"

Surface::Surface(
    const PInstance & instance, 
    const VkSurfaceKHR & surface) 
    : InstanceResource(instance), mSurface(surface) {}

PSurface Surface::CreateSurface(
    const PInstance & instance, void * window, SurfaceCreateFn fn) {
    VkSurfaceKHR surface;
    auto result = fn(*instance, window, &surface);
    if (result != VK_SUCCESS) { return VK_NULL_HANDLE; }
    return PSurface(new Surface(instance, surface));
}

Surface::~Surface() {
    if (mInstance != nullptr && mSurface != VK_NULL_HANDLE) {
        vkDestroySurfaceKHR(*mInstance, mSurface, nullptr); 
    }
}