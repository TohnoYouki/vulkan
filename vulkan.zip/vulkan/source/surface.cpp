#include "surface.h"
#include "instance.h"
#include "physicaldevice.h"

Surface::Surface(const Instance * instance, VkSurfaceKHR surface):
    mInstance(instance), mSurface(surface) {}

bool Surface::PhysicalDeviceSupport(
    const PhysicalDevice * device, int family) const {
    VkBool32 result;
    vkGetPhysicalDeviceSurfaceSupportKHR(*device, family, mSurface, &result);
    return static_cast<bool>(result);
}

PSurface Surface::CreateSurface(
    const Instance * instance, void * window, SurfaceCreateFn fn) {
    VkSurfaceKHR surface;
    auto result = fn(*instance, window, &surface);
    if (result != VK_SUCCESS) { nullptr; }
    return PSurface(new Surface(instance, surface));
}

Surface::~Surface() {
    if (mSurface != VK_NULL_HANDLE) {
        vkDestroySurfaceKHR(*mInstance, mSurface, nullptr);
    }
}