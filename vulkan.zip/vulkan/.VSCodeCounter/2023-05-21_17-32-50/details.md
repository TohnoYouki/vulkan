# Details

Date : 2023-05-21 17:32:50

Directory /home/tohnoyouki/Desktop/vulkan/include

Total : 7 files,  192 codes, 0 comments, 35 blanks, all 227 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [include/core.h](/include/core.h) | C++ | 19 | 0 | 7 | 26 |
| [include/debug.h](/include/debug.h) | C++ | 34 | 0 | 5 | 39 |
| [include/environment.h](/include/environment.h) | C++ | 59 | 0 | 6 | 65 |
| [include/instance.h](/include/instance.h) | C++ | 34 | 0 | 9 | 43 |
| [include/physicaldevice.h](/include/physicaldevice.h) | C++ | 21 | 0 | 4 | 25 |
| [include/resource.h](/include/resource.h) | C++ | 11 | 0 | 1 | 12 |
| [include/surface.h](/include/surface.h) | C++ | 14 | 0 | 3 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)