# Summary

Date : 2023-05-21 17:32:50

Directory /home/tohnoyouki/Desktop/vulkan/include

Total : 7 files,  192 codes, 0 comments, 35 blanks, all 227 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 7 | 192 | 0 | 35 | 227 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 7 | 192 | 0 | 35 | 227 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)